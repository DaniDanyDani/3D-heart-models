import gmsh
import math
import sys

# Inicializa o Gmsh e o kernel 
gmsh.initialize()
gmsh.model.occ.synchronize()
gmsh.logger.start()

# caminhos temporários só para teste
caminho_scar_vol = "/home/daniel/3D-heart-models/teste/meshFiles/Patient_1_scarvol.msh"
caminho_patient_mesh = "/home/daniel/3D-heart-models/teste/meshFiles/Patient_1.msh"

# pega os modelos de malhas como se fosse ir em open
gmsh.merge(caminho_scar_vol)
gmsh.merge(caminho_patient_mesh)

# 
entities_heart = gmsh.model.getEntities(3)  # Entidades do coração (volume)
entities_scar = gmsh.model.getEntities(3)   # Entidades da fibrose (volume)

print(f"Entidades do coração: {entities_heart=}")
print(f"Entidades da fibrose: {entities_scar=}")

if not entities_heart or not entities_scar:
    print("Erro: Não foi possível encontrar as entidades esperadas.")
    gmsh.finalize()
    sys.exit()

# Remove duplicatas e tenta reparar possiveis erros na malha
gmsh.model.mesh.removeDuplicateNodes()
gmsh.model.occ.healShapes()

# Seleciona os volumes do coração e da fibrose, 3 e 13 respectivamente
vol_heart = entities_heart[1][1]  # Volume do coração
vol_scar = entities_scar[0][1]    # Volume da fibrose

print(f"{vol_heart=}")
print(f"{vol_scar=}")

try:
    # Realiza corte
    gmsh.model.occ.cut([(3, vol_heart)], [(3, vol_scar)])
    # gmsh.model.occ.booleanDifference([(3, vol_heart)], [(3, vol_scar)], removeObject=True, removeTool=True)
    gmsh.model.occ.synchronize()  # Sincroniza a operação
except Exception as e:
    print(f"Erro durante a operação de corte: {e}")

gmsh.model.mesh.removeDuplicateNodes()
gmsh.model.occ.healShapes()

# Tenta criar a geometria da malha
try:
    gmsh.model.mesh.generate(3)
except Exception as e:
    print(f"Erro ao criar geometria: {e}")
    gmsh.finalize()
    sys.exit()

log = gmsh.logger.get()
print("Logger has recorded " + str(len(log)) + " lines")
gmsh.logger.stop()


gmsh.write("new_patient_model_without_scar.msh")

if '-nopopup' not in sys.argv:
    gmsh.fltk.run()


gmsh.finalize()
